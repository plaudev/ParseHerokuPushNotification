# 1 Push Notification

Patrick Lau @plaudev 2016-08-25
For use with Rob Pervical's iOS9 course lecture #140 on push notification https://www.udemy.com/the-complete-ios-9-developer-course/learn/v4/content

## 1.1 Introduction

When I began my attempt to get push notification working for Lecture #140 under the Parse/Heroku set up, I decided to deploy a brand new app on that platform for fear of breaking what little I had on the Tinder app set up. This is documentation of my attempt to duplicate the ability of push notification to my Tinder Parse/Heroku app. 

At the outset of this process I had successfully sent push notification from the Terminal shell using curl to my physical iphone and from the parse-dashboard. I have not yet tried sending from the iphone. I have not verified that it works on android.

This readme contains step-by-step instructions to deploy push notifcation (section 2), a list of future implementations/enhancements (section 3) and references I used to devise this implementation (section 4). The instructions are mac based because that's what I use; if you use a PC. hope you can easily find the equivalent of what I'm doing here.

This Parse/Heroku set up involves Node.js which is a form of Javascript. But I'm giving you all the files you need on github so no need to sweat. After you unzip the package, you may want to plop each file in individually so you have a chance to examine what it contains which is very little. If you do know even just a hint of Node.js and/or Javascript - uh-hmm, let me do my best Rob impression here - you can challenge yourself to compose those files yourself. I have no formal knowledge of Node.js and whatever know-how on Javascript I have came from taking Rob's Web Dev Course (plug plug plug, Rob :P). In any case, there is only about 2 pages of .js code and that language is highly readable.

You will also need to do some git & npm. I didn't know all that much about either of them but, if you follow the first two steps I recommend you do, you will know enough about both for our purpose.

Like solving most problems, it always feels a lot harder before reaching the solution than after. It's like building a jigsaw by finding one piece from this stackoverflow post, and another from a different post. In this case, it did not help that one particular online tutorial contains a code typo which threw a lot of people off including myself. Nonetheless, if you just scan the numbered titles of this readme, you will soon find there is not all that much to it.

I'm borrowing some formatting from Markdown (#4.4.7) to make this readme more readable. Apologies to the knowledgeable if I'm misuing it as I don't really know much beyond a quick glance of that wiki page.


# 2 Steps to Deploy Push

Since things change really fast especially on iOS - and you are reading this because parse.com is disappearing - please note that these instructions are essentially effective as of the date of this readme. Should there be a need to update, any bugs or enhancements you think would be useful, please kindly let me know. Good luck!

## 2.1 Deploy Parse Server on Heroku & Parse-Dashboard on Mac

The starting point of these instructions assumes you have already followed Rob's instructions in Lecture #112 to deploy Parse Server on Heroku and those in Lecture #113 to deploy parse-dashboard. If you are stuck trying to figure out those, Geir Fjærli has an excellent & very detailed guide that will very likely help you (#4.1.3).

## 2.2 Set Up Parse Server Locally

### 2.2.1 Bare Bones Node.js Web Server on Heroku
The very first thing I recommend you do is to watch the 6-minute Hot Sauce JS youtube video (#4.4.1) which will show you how easy it is to get a web server up & running. Just use the Heroku Tinder app credentials you already set up. The author seems to be using the Sublime code editor but you can use whatever you have handy. This example it isolates the Heroku/Node.js part from our Parse/Heroku set up and makes clear what is what in this whole process. Optionally, read a bit about Express (#4.4.2) if you like which I never heard of beforehand.

## 2.2.2 Heroku Node.js Server Tutorial
The second thing I recommend you do is to follow the Heroku Node.js Server tutorial (#4.3.1). This tutorial sets up a more complex Herou server example using code they give you. By the end of this tutorial & the previous video, you should: a) have a very good sense of how a Heroku server works; and b) know enough about git & npm. Notice also that up to this point, we have not done a thing about Parse yet.

## 2.2.? Download Files from Github to Mac
Now it's time to download the files 


## 2.3


# 3 Future Implementation & Enhancements

## 3.1 Bugs

### 3.1.1 Notification Title
When device is locked or otherwise app is in background, notificatino alerts somehow retains the title "ParseStarterProject-Swift" instead of new project name "Tinder".

## 3.2 Enhancements for iOS

### 3.2.1 Push from Device

## 3.3 Implementation for Android


# 4 References & Resources

## 4.1 Rob Percival iOS9 Course

### 4.1.1 Rob Percival Parse Starter Project Feb 2016
http://www.robpercival.co.uk/parse-server-on-heroku/

### 4.1.2 Rob Percival Parse Starter Project June 2015
http://www.robpercival.co.uk/parse-working-on-xcode-7swift-2/

### 4.1.3 Geir Fjærli Parse/Heroku Guide
https://www.udemy.com/the-complete-ios-9-developer-course/learn/v4/questions/1460332


## 4.2 Parse

### 4.2.1 Parse iOS Docs
http://parseplatform.github.io/docs/ios/guide/

### 4.2.2 Parse iOS SDK 1.14.2
https://github.com/ParsePlatform/Parse-SDK-iOS-OSX/releases/tag/1.14.2

### 4.2.3 Parse Server Github
https://github.com/ParsePlatform/parse-server-example

### 4.2.4 Parse Server Set Up
https://github.com/ParsePlatform/parse-server/

### 4.2.5 Parse Server Videos
http://blog.parse.com/learn/parse-server-video-series-april-2016/

### 4.2.6 Parse Server Push
https://github.com/ParsePlatform/parse-server/wiki/Push

### 4.2.7 Parse Server Keys
https://github.com/ParsePlatform/parse-server/wiki/Parse-Server-Guide#keys


## 4.3 Heroku

### 4.3.1 Heroku Node.js Server Tutorial
https://devcenter.heroku.com/articles/getting-started-with-nodejs

### 4.3.2 Heroku Toolbelt
https://toolbelt.heroku.com/

### 4.3.3 Heroku Git Authentication
http://stackoverflow.com/a/28331676/1827488

### 4.3.4 Heroku Git Repo Size Zero
https://github.com/ParsePlatform/parse-server/issues/1304

### 4.3.5 Heroku Local Environment Variables
https://devcenter.heroku.com/articles/heroku-local#set-up-your-local-environment-variables


## 4.3 Roger Stringer

### 4.3.1 Roger Stringer Parse/Heroku Deployment Tutorial
http://rogerstringer.com/2016/02/04/parse-server-heroku/

### 4.3.2 Roger Stringer Parse/Heroku Push Notification Tutorial
http://rogerstringer.com/2016/02/11/parse-server-push/


## 4.4 Misc

### 4.4.1 Bare Bone Node.js Web Server on Heroku
https://www.youtube.com/watch?v=vUqB77UO4E0

### 4.4.2 Express
https://www.npmjs.com/package/express

### 4.4.3 Git Push Heroku/Origin Master
http://stackoverflow.com/a/32238628/1827488

### 4.4.4 APNS Cannot Find Vaild Connection To Device
https://github.com/ParsePlatform/parse-server/issues/1282

### 4.4.5 Generating PEM Files (Red Herring)
http://stackoverflow.com/a/38180025/1827488
https://www.raywenderlich.com/123862/push-notifications-tutorial
http://serverfault.com/a/9717
https://github.com/ParsePlatform/parse-server/issues/697

### 4.4.6 Show Hidden Files in Finder
http://ianlunn.co.uk/articles/quickly-showhide-hidden-files-mac-os-x-mavericks/

### 4.4.7 Markdown .md
https://en.wikipedia.org/wiki/Markdown


# 5 My Files

## 5.1 Everything You Need is Here
https://github.com/plaudev/ParseHerokuPushNotification
