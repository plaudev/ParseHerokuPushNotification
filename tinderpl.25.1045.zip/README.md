# 1.0 Push Notification

Patrick Lau @plaudev 2016-08-25
For use with Rob Pervical's iOS9 course lecture #140 on push notification https://www.udemy.com/the-complete-ios-9-developer-course/learn/v4/content

## 1.1 Introduction

When I began my attempt to get push notification working for Lecture #140 under the Parse/Heroku set up, I decided to deploy a brand new app on that platform for fear of breaking what little I had on the Tinder app set up. This is documentation of my attempt to duplicate the ability of push notification to my Tinder Parse/Heroku app. 

At the outset of this process I had successfully sent push notification from the Terminal shell using curl to my physical iphone and from the parse-dashboard. I have not yet tried sending from the iphone. I have not verified that it works on android.


# 2.0 Steps to Deploy Push




# 3.0 Future Implementation

## 3.1 Bugs

### 3.1.1 Notification Title
When device is locked or otherwise app is in background, notificatino alerts somehow retains the title "ParseStarterProject-Swift" instead of new project name "Tinder".


# 4.0 References & Resources

## 4.1 Rob Percival iOS9 Course

### 4.1.1 Rob Percival Parse Starter Project Feb 2016
http://www.robpercival.co.uk/parse-server-on-heroku/

### 4.1.2 Rob Percival Parse Starter Project June 2015
http://www.robpercival.co.uk/parse-working-on-xcode-7swift-2/

### 4.1.3 Geir Fjærli Parse/Heroku Guide
https://www.udemy.com/the-complete-ios-9-developer-course/learn/v4/questions/1460332


## 4.2 Parse

### 4.2.1 Parse iOS Docs
http://parseplatform.github.io/docs/ios/guide/

### 4.2.2 Parse iOS SDK 1.14.2
https://github.com/ParsePlatform/Parse-SDK-iOS-OSX/releases/tag/1.14.2

### 4.2.3 Parse Server Github
https://github.com/ParsePlatform/parse-server-example
https://github.com/ParsePlatform/parse-server/
https://github.com/ParsePlatform/parse-server/wiki/Push
https://github.com/ParsePlatform/parse-server/wiki/Parse-Server-Guide#keys
https://github.com/parse-server-modules/parse-server-push-adapter

### 4.2.4 Parse Server Videos
http://blog.parse.com/learn/parse-server-video-series-april-2016/


## 4.3 Heroku

### 4.3.1 Heroku Server Tutorial
https://devcenter.heroku.com/articles/getting-started-with-nodejs

### 4.3.2 Heroku Toolbelt
https://toolbelt.heroku.com/

### 4.3.3 Heroku Git Authentication
http://stackoverflow.com/a/28331676/1827488

### 4.3.4 Heroku Git Repo Size Zero
https://github.com/ParsePlatform/parse-server/issues/1304

### 4.3.5 Heroku Local Environment Variables
https://devcenter.heroku.com/articles/heroku-local#set-up-your-local-environment-variables


## 4.3 Roger Stringer

### 4.3.1 Roger Stringer Parse/Heroku Deployment Tutorial
http://rogerstringer.com/2016/02/04/parse-server-heroku/

### 4.3.2 Roger Stringer Parse/Heroku Push Notification Tutorial
http://rogerstringer.com/2016/02/11/parse-server-push/


## 4.4 Misc

### 4.4.1 Bare Bone Node.js Web Server Example
https://www.youtube.com/watch?v=vUqB77UO4E0

### 4.4.2 Express
https://www.npmjs.com/package/express

### 4.4.3 Git Push Heroku/Origin Master
http://stackoverflow.com/a/32238628/1827488

### 4.4.4 APNS Cannot Find Vaild Connection To Device
https://github.com/ParsePlatform/parse-server/issues/1282

### 4.4.5 Generating PEM Files (Red Herring)
http://stackoverflow.com/a/38180025/1827488
https://www.raywenderlich.com/123862/push-notifications-tutorial
http://serverfault.com/a/9717
https://github.com/ParsePlatform/parse-server/issues/697

### 4.4.6 Show Hidden Files in Finder
http://ianlunn.co.uk/articles/quickly-showhide-hidden-files-mac-os-x-mavericks/
